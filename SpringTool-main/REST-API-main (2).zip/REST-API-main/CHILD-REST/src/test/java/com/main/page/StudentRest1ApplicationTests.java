package com.main.page;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentRest1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
