package com.main.page;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class StudentRest1Application {

	public static void main(String[] args) {
		SpringApplication.run(StudentRest1Application.class, args);
	}

}
