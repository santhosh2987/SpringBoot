package com.main.order;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OrderKartApplication {

	public static void main(String[] args) {
		SpringApplication.run(OrderKartApplication.class, args);
	}

}
